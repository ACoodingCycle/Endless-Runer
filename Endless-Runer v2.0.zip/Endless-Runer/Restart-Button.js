const button = document.querySelector("button");
button.addEventListener("click", (event) => {
    window.location.reload();
});
